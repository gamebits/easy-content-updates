<?php
/**
* Plugin Name: SEO to Excerpt
* Plugin URI: https://github.com/gamebits/easy-updates-old-content
* Description: Copies each post's Yoast (or, as a fallback the All In One SEO Pack) SEO description to the excerpt field.
* Version: 1.0.0
* Author: Ken Gagne
* Author URI: https://wordpress.stackexchange.com/a/71014
* License: GPL2
* Text Domain: seo-to-excerpt
* Domain Path: /languages/
**/

register_activation_hook( __FILE__, 'wpse_70990_activation_run' );

function wpse_70990_activation_run()
{   
    $args = array( 
        'post_type'   => 'post',
        'numberposts' => -1,
        'post_status' => 'publish',
    );

    $posts = get_posts( $args );

    foreach ( $posts as $post )
    {
        if( '' == $post->post_excerpt )
        {
            // First, trying to get Yoast SEO Description
            $seo_excerpt = get_post_meta( $post->ID, '_yoast_wpseo_metadesc' ,true);
            
            if( '' == $seo_excerpt ) {
                // If Yoast SEO description not found, try getting AIOSEOP Description.
                $seo_excerpt = get_post_meta( $post->ID, '_aioseop_description' ,true);
            }

            if( '' != $seo_excerpt ) {
                $po = array();
                $po = get_post( $post->ID, 'ARRAY_A' );
                $po['post_excerpt'] = $seo_excerpt;
                wp_update_post($po);
            }
        }
    }   
}